class Song:
    def __init__(self, title, artist, year, status):
        """
            Initialize required attributes for a Song
        """
        self.title = title
        self.artist = artist
        self.year = year
        self.status = status

    def mark_song(self, status):
        """
            Mark a song as required/learned
        """
        self.status = status
