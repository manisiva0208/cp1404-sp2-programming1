MENU = "Menu: \n L - List songs \n A - Add new song \n C - Complete a song \n Q - Quit"


def load_songs(songs):
    song_file = open("songs.csv", 'r')
    for line in song_file:
        line_string = line.split(",")
        songs.append([line_string[0], line_string[1], int(line_string[2]), line_string[3].strip()])
        songs.sort(key=lambda l: (l[1]))
    song_file.close()
    print(len(songs), "songs loaded from songs.csv")


def print_songs(songs):
    not_learned = 0
    learned = 0
    song_no = 0
    for song in songs:
        if song[3] == 'n':
            print(song_no, ".", "{:3}".format(""), format(song[0], str(30)), "- ", format(song[1], str(20)), "(",
                  song[2], ")")
            song_no += 1
            learned += 1
        elif song[3] == 'y':
            print(song_no, ".", " * ", format(song[0], str(30)), "- ", format(song[1], str(20)), "(",
                  song[2], ")")
            song_no += 1
            not_learned += 1
    print(learned, "songs learned,", not_learned, "songs still to learn")


def add_song(songs):
    title = input("Title: ").strip()
    while title == "":
        print("Input can not be blank")
        title = input("Title: ").strip()

    artist = input("Artist: ").strip()
    while artist == "":
        print("Input can not be blank")
        artist = input("Artist: ").strip()

    while True:
        try:
            year = int(input("Year: "))
            if year < 0:
                print("Number must be >= 0")
            elif year > 0:
                break
        except ValueError:
            print("Invalid input; enter a valid number")

    songs.append([title, artist, year, 'y'])
    songs.sort(key=lambda l: (l[1]))
    print(title, "by", artist, "(" + str(year) + ")", "added to song list")


def is_songs_left(songs):
    songs_completed = 0
    for song in songs:
        if song[3] == 'n':
            songs_completed += 1
    if len(songs) == songs_completed:
        return False
    else:
        return True


def complete_song(songs):
    if is_songs_left(songs):
        print("Enter the number of a song to mark as learned")
        while True:
            try:
                index = int(input(">>> "))
                if index < 0:
                    raise IndexError
                else:
                    if songs[index][3] == 'y':
                        print(songs[index][0], "by", songs[index][1], "learned")
                        songs[index][3] = 'n'
                        break
                    elif songs[index][3] == 'n':
                        print("You have already learned", songs[index][0])
                        break
            except IndexError:
                print("Invalid song number")
            except ValueError:
                print("Invalid input; enter a valid number")
    else:
        print("No more songs to learn!")


def write_file(songs):
    open_file = open("songs.csv", 'w')

    for song in songs:
        open_file.write(
            str(song[0]) + "," + song[1] + "," + str(song[2]) + "," + song[3] + "\n")
    open_file.close()
    print(len(songs), "songs saved to songs.csv")


def main():
    print("Songs To Learn 1.0 - by Sivaraman Manikandaraj")
    songs = []
    load_songs(songs)

    print(MENU)
    menu_select = input(">>>").upper().strip()
    while menu_select != 'Q':
        if menu_select == 'L':
            print_songs(songs)
        elif menu_select == 'A':
            add_song(songs)
        elif menu_select == 'C':
            complete_song(songs)
        else:
            print("Invalid menu choice")
        print(MENU)
        menu_select = input(">>>").upper()
    write_file(songs)
    print("Have a nice day :)")


main()
